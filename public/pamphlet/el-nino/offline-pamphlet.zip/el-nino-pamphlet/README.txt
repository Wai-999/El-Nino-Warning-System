အယ်လ်နီညို လက်ကမ်းစာစောင် — အော့ဖ်လိုင်း ပက်ကေ့ (2026-10, build a396892b90ad)
=====================================================================
• pdf/DUSU-ElNino-Bifold-2026-10-e1.pdf — ပုံနှိပ်မူ PDF အပြည့်အစုံ (ဖုန်းတိုင်းတွင် ဖွင့်နိုင်သည်)။
• index.html — စာသားဗားရှင်း၊ ရင်းမြစ်စာရင်း (ဖိုင်မန်နေဂျာ/ဘရောက်ဇာဖြင့် ဖွင့်ပါ; ရှာဖွေခြင်း/အော့ဖ်လိုင်းခလုတ် မပါ)။
• data/bibliography.txt — ရင်းမြစ် စာရင်း (စာသား)။
အွန်လိုင်း နောက်ဆုံးဗားရှင်း — https://wai-999.github.io/El-Nino-Warning-System/pamphlet/el-nino/
Facebook နှင့် မူရင်းရင်းမြစ် လင့်ခ်များအတွက် အင်တာနက် လိုသည်။

El Niño leaflet — portable offline package. Open pdf/DUSU-ElNino-Bifold-2026-10-e1.pdf (any PDF viewer) or index.html (text + sources).
Latest version online: https://wai-999.github.io/El-Nino-Warning-System/pamphlet/el-nino/
